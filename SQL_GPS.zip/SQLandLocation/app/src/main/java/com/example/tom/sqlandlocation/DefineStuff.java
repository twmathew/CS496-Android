package com.example.tom.sqlandlocation;


public class DefineStuff {

    public static final int PERMISSION_GRANTED = 0;

    public static final int PERMISSION_DENIED = -1;
}
