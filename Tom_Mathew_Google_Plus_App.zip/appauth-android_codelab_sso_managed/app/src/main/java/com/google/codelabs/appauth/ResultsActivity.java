
package com.google.codelabs.appauth;

import android.app.Application;

public class ResultsActivity extends Application {


    @Override
    public void onCreate() {
        super.onCreate();
    }
}
