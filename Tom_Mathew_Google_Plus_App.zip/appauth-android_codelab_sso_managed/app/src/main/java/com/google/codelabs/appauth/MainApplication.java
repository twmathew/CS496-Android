
package com.google.codelabs.appauth;

import android.app.Application;

public class MainApplication extends Application {

  public static final String LOG_TAG = "AppAuthSample";

  @Override
  public void onCreate() {
    super.onCreate();
  }
}
